//
//  ContentView.swift
//  Serendib_buddy
//
//  Created by IM Student on 2025-11-23.
//

import SwiftUI
import Combine
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Item>

    @State private var searchText: String = ""
    @AppStorage("profile.name") private var storedName: String = ""

    private struct MenuItem: Identifiable {
        let id = UUID()
        let title: String
        let destination: AnyView
    }

// MARK: - Brand Badge
struct BrandBadge: View {
    var body: some View {
        HStack(spacing: 10) {
            AppLogoView()
                .frame(width: 28, height: 28)
            Text("Travel Buddy Matcher")
                .font(.subheadline).bold()
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(
            LinearGradient(colors: [BrandColors.gradientStart.opacity(0.15), BrandColors.gradientEnd.opacity(0.15)], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(BrandColors.primary.opacity(0.12), lineWidth: 1)
        )
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

    private var allMenuItems: [MenuItem] {
        [
            MenuItem(title: "Matching", destination: AnyView(MatchingView())),
            MenuItem(title: "Suggestions", destination: AnyView(SuggestionsView())),
            MenuItem(title: "Trip Plan", destination: AnyView(TripPlanView()))
        ]
    }

    private var filteredMenuItems: [MenuItem] {
        guard !searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return allMenuItems }
        return allMenuItems.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                // Header with greeting and profile button
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Hello, \(storedName.isEmpty ? "Traveler" : storedName)")
                            .font(.headline)
                        Text("Where to next?")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    NavigationLink(destination: ProfileView()) {
                        Image(systemName: "person.crop.circle")
                            .font(.title2)
                            .foregroundColor(BrandColors.primary)
                            .padding(8)
                            .background(Color.gray.opacity(0.15))
                            .clipShape(Circle())
                            .accessibilityLabel("Open Profile")
                    }
                }
                .padding(.horizontal)

                // Brand badge just below header
                BrandBadge()
                    .padding(.horizontal)

                // Integrated Onboarding section with animated slideshow + name overlay
                ZStack(alignment: .topLeading) {
                    SlideshowHero(
                        title: "Discover Sri Lanka",
                        subtitle: "Match with local student buddies",
                        imageURLs: [
                            URL(string: "https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1600&auto=format&fit=crop")!,
                            URL(string: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?q=80&w=1600&auto=format&fit=crop")!,
                            URL(string: "https://images.unsplash.com/photo-1600500731216-c89d9b3da01f?q=80&w=1600&auto=format&fit=crop")!,
                            URL(string: "https://images.unsplash.com/photo-1616789914319-07e675985d8a?q=80&w=1600&auto=format&fit=crop")!
                        ],
                        interval: 4
                    )
                    Text("Travel Buddy Matcher")
                        .font(.caption).bold()
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                        .padding(12)
                        .foregroundColor(.primary)
                }
                .padding(.horizontal)

                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "person.2.fill").foregroundColor(BrandColors.primary)
                        Text("Smart buddy matching").font(.subheadline)
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "map.fill").foregroundColor(BrandColors.primary)
                        Text("Personalized destination suggestions").font(.subheadline)
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "calendar.badge.plus").foregroundColor(BrandColors.primary)
                        Text("Plan your itinerary with ease").font(.subheadline)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)

                if storedName.isEmpty {
                    NavigationLink("Create Profile", destination: ProfileView())
                        .buttonStyle(.borderedProminent)
                        .tint(BrandColors.primary)
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal)
                }

                // Menu list
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(filteredMenuItems) { item in
                        NavigationLink(destination: item.destination) {
                            HStack {
                                Image(systemName: iconForMenu(title: item.title))
                                    .foregroundColor(BrandColors.primary)
                                Text(item.title)
                                Spacer()
                                Image(systemName: "chevron.right").foregroundColor(.secondary)
                            }
                            .padding()
                            .background(.thinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(BrandColors.primary.opacity(0.08), lineWidth: 1)
                            )
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal)
                    }
                }
                }
            }
            .navigationTitle("Travel Buddy Matcher")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search features")
            .tint(BrandColors.primary)
            .toolbarBackground(
                LinearGradient(colors: [BrandColors.gradientStart, BrandColors.gradientEnd],
                               startPoint: .topLeading, endPoint: .bottomTrailing),
                for: .navigationBar
            )
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.light, for: .navigationBar)
        }
    }

    private func addItem() {}
    private func deleteItems(offsets: IndexSet) {}
    private func iconForMenu(title: String) -> String {
        switch title {
        case "Profile": return "person.crop.circle"
        case "Matching": return "person.2"
        case "Suggestions": return "sparkles"
        case "Trip Plan": return "calendar"
        default: return "square.grid.2x2"
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}

// MARK: - Slideshow Hero
struct SlideshowHero: View {
    let title: String
    let subtitle: String
    let imageURLs: [URL]
    let interval: TimeInterval

    @State private var index: Int = 0
    private var timer: Publishers.Autoconnect<Timer.TimerPublisher> {
        Timer.publish(every: interval, on: .main, in: .common).autoconnect()
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                ForEach(Array(imageURLs.enumerated()), id: \.offset) { i, url in
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .empty:
                            Color.gray.opacity(0.15)
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFill()
                        case .failure:
                            ZStack {
                                Image(systemName: "photo")
                                    .font(.largeTitle)
                                    .foregroundColor(.secondary)
                            }
                            .background(Color.gray.opacity(0.15))
                        @unknown default:
                            EmptyView()
                        }
                    }
                    .opacity(i == index ? 1 : 0)
                    .animation(.easeInOut(duration: 0.8), value: index)
                }
            }
            .frame(height: 240)
            .clipped()

            LinearGradient(colors: [.clear, .black.opacity(0.6)], startPoint: .center, endPoint: .bottom)
                .frame(height: 120)
                .frame(maxWidth: .infinity, alignment: .bottom)

            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.title).bold().foregroundColor(.white)
                Text(subtitle).font(.subheadline).foregroundColor(.white.opacity(0.9))
            }
            .padding()
        }
        .frame(height: 240)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(radius: 6)
        .onReceive(timer) { _ in
            guard !imageURLs.isEmpty else { return }
            withAnimation(.easeInOut(duration: 0.8)) {
                index = (index + 1) % imageURLs.count
            }
        }
    }
}
