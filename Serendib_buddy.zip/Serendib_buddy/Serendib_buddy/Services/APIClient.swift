import Foundation

protocol DestinationsAPI {
    func fetchAll() async throws -> [DestinationDTO]
}

struct DestinationDTO: Codable, Equatable, Identifiable {
    let id: UUID
    let name: String
    let region: String
}

final class LocalDestinationsAPI: DestinationsAPI {
    func fetchAll() async throws -> [DestinationDTO] {
        // Placeholder local data; can be replaced by bundled JSON
        return [
            DestinationDTO(id: UUID(), name: "Sigiriya", region: "Central"),
            DestinationDTO(id: UUID(), name: "Galle Fort", region: "Southern")
        ]
    }
}
