import SwiftUI

struct SplashView: View {
    @Binding var isActive: Bool
    @State private var scale: CGFloat = 0.8
    @State private var opacity: Double = 0.0

    var body: some View {
        ZStack {
            LinearGradient(colors: [BrandColors.gradientStart, BrandColors.gradientEnd], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            AppLogoView()
                .frame(width: 140, height: 140)
                .scaleEffect(scale)
                .opacity(opacity)
                .onAppear {
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                        scale = 1.0
                    }
                    withAnimation(.easeIn(duration: 0.6)) {
                        opacity = 1.0
                    }
                    // Dismiss after delay
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        withAnimation(.easeInOut(duration: 0.5)) {
                            isActive = false
                        }
                    }
                }
        }
        .transition(.opacity.combined(with: .scale))
        .accessibilityAddTraits(.isHeader)
        .accessibilityLabel("Launching Travel Buddy Matcher")
    }
}

#Preview {
    StatefulPreviewWrapper(true) { SplashView(isActive: $0) }
}

// Helper for previews only
struct StatefulPreviewWrapper<Value, Content: View>: View {
    @State var value: Value
    var content: (Binding<Value>) -> Content
    init(_ value: Value, content: @escaping (Binding<Value>) -> Content) {
        _value = State(initialValue: value)
        self.content = content
    }
    var body: some View { content($value) }
}
