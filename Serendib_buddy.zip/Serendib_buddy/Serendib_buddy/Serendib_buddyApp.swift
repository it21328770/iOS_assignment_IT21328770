//
//  Serendib_buddyApp.swift
//  Serendib_buddy
//
//  Created by IM Student on 2025-11-23.
//

import SwiftUI
import CoreData

@main
struct Serendib_buddyApp: App {
    let persistenceController = PersistenceController.shared
    @State private var showSplash: Bool = true

    var body: some Scene {
        WindowGroup {
            ZStack {
                if showSplash {
                    SplashView(isActive: $showSplash)
                        .transition(.opacity.combined(with: .scale))
                } else {
                    ContentView()
                        .transition(.opacity.combined(with: .scale))
                }
            }
            .environment(\.managedObjectContext, persistenceController.container.viewContext)
            .animation(.easeInOut(duration: 0.5), value: showSplash)
        }
    }
}
