import SwiftUI

enum BrandColors {
    // Option B: Emerald Heritage
    // Primary: #0E7C66, Accent: #F2E8CF
    static let primary = Color(red: 14/255, green: 124/255, blue: 102/255)
    static let accent = Color(red: 242/255, green: 232/255, blue: 207/255)

    // Gradient background for icon (darker to primary)
    static let gradientStart = Color(red: 6/255, green: 82/255, blue: 67/255)
    static let gradientEnd = primary
}
