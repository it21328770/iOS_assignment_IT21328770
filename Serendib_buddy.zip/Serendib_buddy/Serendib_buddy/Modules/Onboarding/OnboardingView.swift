import SwiftUI

struct OnboardingView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                AppLogoView()
                    .frame(width: 96, height: 96)
                    .padding(.top, 8)
                HeroHeader(
                    title: "Discover Sri Lanka",
                    subtitle: "Match with local student buddies",
                    imageURL: URL(string: "https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1600&auto=format&fit=crop")!
                )
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: "person.2.fill").foregroundColor(.blue)
                        Text("Smart buddy matching").font(.subheadline)
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "map.fill").foregroundColor(.green)
                        Text("Personalized destination suggestions").font(.subheadline)
                    }
                    HStack(spacing: 12) {
                        Image(systemName: "calendar.badge.plus").foregroundColor(.orange)
                        Text("Plan your itinerary with ease").font(.subheadline)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 4)
                NavigationLink("Create Profile", destination: ProfileView())
                    .buttonStyle(.borderedProminent)
                    .tint(BrandColors.primary)
            }
            .padding()
        }
        .navigationTitle("Onboarding")
    }
}

#Preview {
    NavigationStack { OnboardingView() }
}
