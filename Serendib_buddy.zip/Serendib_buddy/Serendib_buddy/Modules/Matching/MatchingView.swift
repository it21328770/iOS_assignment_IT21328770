import SwiftUI
import Combine
import UIKit

struct Buddy: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let languages: [String]
    let interests: [String]
}

final class MatchingViewModel: ObservableObject {
    @Published var candidates: [Buddy] = [
        .init(name: "Nimal", languages: ["Sinhala", "English"], interests: ["History", "Hiking"]),
        .init(name: "Sumi", languages: ["Tamil", "English"], interests: ["Food", "Beaches"]),
        .init(name: "Kavi", languages: ["English"], interests: ["Culture", "Wildlife"]) 
    ]
    @Published var favorites: [Buddy] = []
    @Published var dislikes: [Buddy] = []
    func likeTop() { if let first = candidates.first { favorites.append(first); candidates.removeFirst() } }
    func dislikeTop() { if let first = candidates.first { dislikes.append(first); candidates.removeFirst() } }
}

struct MatchingView: View {
    @StateObject private var vm = MatchingViewModel()
    @State private var trigger: SwipeDirection? = nil
    @State private var showToast: Bool = false
    @State private var lastAction: String = ""
    @AppStorage("profile.name") private var profName: String = ""
    @AppStorage("profile.city") private var profCity: String = ""
    @AppStorage("profile.country") private var profCountry: String = ""
    @AppStorage("profile.languages") private var profLangs: String = ""

    var body: some View {
        ZStack(alignment: .top) {
            VStack {
                if !(profName.isEmpty && profCity.isEmpty && profLangs.isEmpty) {
                    ProfileSummaryCard(name: profName, location: locationText, languages: profLangs)
                        .padding(.horizontal)
                        .padding(.top, 6)
                }
            if let top = vm.candidates.first {
                SwipeCardView(
                    content: {
                        VStack(spacing: 8) {
                            Text(top.name).font(.title2).bold()
                            Text("Languages: \(top.languages.joined(separator: ", "))")
                                .foregroundColor(.secondary)
                            Text("Interests: \(top.interests.joined(separator: ", "))")
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .background(.thinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    },
                    onSwipeLeft: { withAnimation(.spring()) { vm.dislikeTop() } },
                    onSwipeRight: { withAnimation(.spring()) { vm.likeTop() } },
                    trigger: $trigger
                )
                .padding()
            } else {
                Text("No more candidates")
                    .foregroundColor(.secondary)
            }
            Spacer()
            HStack(spacing: 24) {
                // Navigate left
                Button { performDislike(animated: true) } label: {
                    Image(systemName: "chevron.left.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                }
                // Dislike
                ZStack(alignment: .topTrailing) {
                    Button { performDislike(animated: true) } label: {
                        Image(systemName: "hand.thumbsdown.fill")
                            .font(.title)
                            .foregroundColor(.red)
                            .padding(12)
                            .background(Color.red.opacity(0.1))
                            .clipShape(Circle())
                    }
                    if !vm.dislikes.isEmpty {
                        Text("\(vm.dislikes.count)")
                            .font(.caption2).bold()
                            .padding(4)
                            .background(Color.red)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            .offset(x: 8, y: -8)
                    }
                }
                // Favorite / Like
                ZStack(alignment: .topTrailing) {
                    Button { performLike(animated: true) } label: {
                        Image(systemName: "heart.fill")
                            .font(.title)
                            .foregroundColor(.pink)
                            .padding(12)
                            .background(Color.pink.opacity(0.1))
                            .clipShape(Circle())
                    }
                    if !vm.favorites.isEmpty {
                        Text("\(vm.favorites.count)")
                            .font(.caption2).bold()
                            .padding(4)
                            .background(Color.pink)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            .offset(x: 8, y: -8)
                    }
                }
                // Navigate right
                Button { performLike(animated: true) } label: {
                    Image(systemName: "chevron.right.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                }
            }
            .padding(.bottom, 8)
            NavigationLink("See Suggestions", destination: SuggestionsView())
                .buttonStyle(.borderedProminent)
                .padding()
            }
            if showToast {
                Text(lastAction)
                    .font(.subheadline).bold()
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                    .shadow(radius: 4)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .navigationTitle("Matching")
        .animation(.easeInOut(duration: 0.25), value: showToast)
    }
}

// MARK: - Actions & Haptics
extension MatchingView {
    private func performLike(animated: Bool) {
        let gen = UINotificationFeedbackGenerator(); gen.notificationOccurred(.success)
        lastAction = "Added to Favorites"
        showQuickToast()
        if animated { trigger = .right } else { vm.likeTop() }
    }

    private func performDislike(animated: Bool) {
        let gen = UINotificationFeedbackGenerator(); gen.notificationOccurred(.warning)
        lastAction = "Marked as Disliked"
        showQuickToast()
        if animated { trigger = .left } else { vm.dislikeTop() }
    }

    private func showQuickToast() {
        withAnimation { showToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            withAnimation { showToast = false }
        }
    }
}

// MARK: - Profile Summary
private extension MatchingView {
    var locationText: String {
        let city = profCity.trimmingCharacters(in: .whitespaces)
        let country = profCountry.trimmingCharacters(in: .whitespaces)
        switch (city.isEmpty, country.isEmpty) {
        case (true, true): return ""
        case (false, true): return city
        case (true, false): return country
        default: return "\(city), \(country)"
        }
    }
}

struct ProfileSummaryCard: View {
    let name: String
    let location: String
    let languages: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: "person.crop.circle").foregroundColor(BrandColors.primary)
                Text(name.isEmpty ? "Profile" : name).font(.subheadline).bold()
                Spacer()
            }
            HStack(spacing: 12) {
                if !location.isEmpty {
                    Label(location, systemImage: "mappin.and.ellipse").font(.caption)
                }
                if !languages.isEmpty {
                    Label(languages, systemImage: "globe").font(.caption)
                }
            }
            .foregroundColor(.secondary)
        }
        .padding(10)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.06), radius: 4, x: 0, y: 2)
    }
}

#Preview {
    NavigationStack { MatchingView() }
}
