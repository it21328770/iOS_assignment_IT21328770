import SwiftUI
import Combine

final class ProfileViewModel: ObservableObject {
    @Published var name: String = ""
    @Published var role: String = "Tourist"
    @Published var age: String = ""
    @Published var gender: String = "Prefer not to say"
    @Published var country: String = ""
    @Published var city: String = ""
    @Published var selectedLanguages: Set<String> = ["English"]
    @Published var selectedInterests: Set<String> = ["Beaches", "Culture"]
}

struct ProfileView: View {
    @StateObject private var vm = ProfileViewModel()
    @AppStorage("profile.name") private var storedName: String = ""
    @AppStorage("profile.role") private var storedRole: String = "Tourist"
    @AppStorage("profile.age") private var storedAge: String = ""
    @AppStorage("profile.gender") private var storedGender: String = "Prefer not to say"
    @AppStorage("profile.country") private var storedCountry: String = ""
    @AppStorage("profile.city") private var storedCity: String = ""
    @AppStorage("profile.languages") private var storedLanguages: String = "English"
    @AppStorage("profile.interests") private var storedInterests: String = "Beaches,Culture"

    @State private var languagesList = ["English", "Sinhala", "Tamil", "French", "German", "Spanish"]
    @State private var interestsList = ["Beaches", "Culture", "Wildlife", "History", "Food", "Hiking", "Surfing", "Tea", "Train Rides"]
    @State private var showLangSheet = false
    @State private var showLangPicker = false
    @State private var showInterestSheet = false
    @State private var customLang: String = ""
    @State private var customInterest: String = ""
    @State private var ageError: String? = nil

    var body: some View {
        Form {
            Section("Basics") {
                TextField("Name", text: $vm.name)
                Picker("Role", selection: $vm.role) {
                    Text("Tourist").tag("Tourist")
                    Text("Local").tag("Local")
                }
                .pickerStyle(.segmented)
                HStack {
                    Text("Age")
                    TextField("e.g. 22", text: $vm.age)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                }
                if let ageError { Text(ageError).font(.caption).foregroundColor(.red) }
                Picker("Gender", selection: $vm.gender) {
                    Text("Male").tag("Male")
                    Text("Female").tag("Female")
                    Text("Non-binary").tag("Non-binary")
                    Text("Prefer not to say").tag("Prefer not to say")
                }
                HStack {
                    Text("Country")
                    TextField("e.g. Sri Lanka", text: $vm.country)
                        .multilineTextAlignment(.trailing)
                        .textInputAutocapitalization(.words)
                }
                HStack {
                    Text("City")
                    TextField("e.g. Colombo", text: $vm.city)
                        .multilineTextAlignment(.trailing)
                        .textInputAutocapitalization(.words)
                }
            }
            Section("Preferences") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Languages").font(.subheadline).foregroundColor(.secondary)
                    Button {
                        showLangPicker = true
                    } label: {
                        HStack {
                            Image(systemName: "list.bullet")
                            Text("Select Languages")
                            Spacer()
                            Text(vm.selectedLanguages.isEmpty ? "None" : vm.selectedLanguages.sorted().joined(separator: ", "))
                                .lineLimit(1)
                                .truncationMode(.tail)
                                .foregroundColor(.secondary)
                        }
                    }
                    Button {
                        customLang = ""; showLangSheet = true
                    } label: { Label("Add other language", systemImage: "plus.circle") }
                }
                VStack(alignment: .leading, spacing: 8) {
                    Text("Interests").font(.subheadline).foregroundColor(.secondary)
                    FlexibleChipGrid(items: interestsList, selection: $vm.selectedInterests)
                    Button {
                        customInterest = ""; showInterestSheet = true
                    } label: {
                        Label("Add other interest", systemImage: "plus.circle")
                    }
                }
            }
            Section {
                NavigationLink("Find Matches", destination: MatchingView())
            }
            Section("Summary") {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Languages: \(vm.selectedLanguages.sorted().joined(separator: ", "))")
                    Text("Interests: \(vm.selectedInterests.sorted().joined(separator: ", "))")
                    Text("Location: \(vm.city.isEmpty ? "—" : vm.city), \(vm.country.isEmpty ? "—" : vm.country)")
                }
                .foregroundColor(.secondary)
            }
        }
        .navigationTitle("Profile")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Save") {
                    if validateAge() == false { return }
                    storedName = vm.name
                    storedRole = vm.role
                    storedAge = vm.age
                    storedGender = vm.gender
                    storedCountry = vm.country
                    storedCity = vm.city
                    storedLanguages = vm.selectedLanguages.sorted().joined(separator: ",")
                    storedInterests = vm.selectedInterests.sorted().joined(separator: ",")
                }
            }
        }
        .onAppear {
            // Pre-fill from stored values
            if vm.name.isEmpty { vm.name = storedName }
            if vm.role.isEmpty == false { vm.role = storedRole }
            if vm.age.isEmpty { vm.age = storedAge }
            if !storedGender.isEmpty { vm.gender = storedGender }
            if vm.country.isEmpty { vm.country = storedCountry }
            if vm.city.isEmpty { vm.city = storedCity }
            let langs = storedLanguages.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
            if !langs.isEmpty { vm.selectedLanguages = Set(langs) }
            let ints = storedInterests.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
            if !ints.isEmpty { vm.selectedInterests = Set(ints) }
        }
        .onChange(of: vm.age) { _ in _ = validateAge() }
        .sheet(isPresented: $showLangSheet) {
            NavigationStack {
                Form {
                    Section("Custom Language") {
                        TextField("e.g. Japanese", text: $customLang)
                            .autocapitalization(.words)
                    }
                }
                .navigationTitle("Add Language")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { showLangSheet = false } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Add") {
                            let trimmed = customLang.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !trimmed.isEmpty else { showLangSheet = false; return }
                            if !languagesList.contains(where: { $0.caseInsensitiveCompare(trimmed) == .orderedSame }) {
                                languagesList.append(trimmed)
                            }
                            vm.selectedLanguages.insert(trimmed)
                            showLangSheet = false
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showLangPicker) {
            NavigationStack {
                LanguagesPickerView(allItems: $languagesList, selection: $vm.selectedLanguages, onAddCustom: {
                    showLangPicker = false
                    customLang = ""; showLangSheet = true
                })
            }
        }
        .sheet(isPresented: $showInterestSheet) {
            NavigationStack {
                Form {
                    Section("Custom Interest") {
                        TextField("e.g. Photography", text: $customInterest)
                            .autocapitalization(.words)
                    }
                }
                .navigationTitle("Add Interest")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { showInterestSheet = false } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Add") {
                            let trimmed = customInterest.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !trimmed.isEmpty else { showInterestSheet = false; return }
                            if !interestsList.contains(where: { $0.caseInsensitiveCompare(trimmed) == .orderedSame }) {
                                interestsList.append(trimmed)
                            }
                            vm.selectedInterests.insert(trimmed)
                            showInterestSheet = false
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    NavigationStack { ProfileView() }
}

struct FlexibleChipGrid: View {
    let items: [String]
    @Binding var selection: Set<String>

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 8, alignment: .leading)], spacing: 8) {
            ForEach(items, id: \.self) { item in
                Button(action: { toggle(item) }) {
                    HStack(spacing: 6) {
                        Image(systemName: selection.contains(item) ? "checkmark.circle.fill" : "circle")
                        Text(item)
                    }
                    .font(.caption)
                    .padding(.horizontal, 10).padding(.vertical, 8)
                    .background(selection.contains(item) ? BrandColors.primary.opacity(0.15) : Color.gray.opacity(0.12))
                    .foregroundColor(selection.contains(item) ? BrandColors.primary : .primary)
                    .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Toggle \(item)")
            }
        }
    }

    private func toggle(_ item: String) {
        if selection.contains(item) { selection.remove(item) } else { selection.insert(item) }
    }
}

// MARK: - Languages Picker
struct LanguagesPickerView: View {
    @Binding var allItems: [String]
    @Binding var selection: Set<String>
    var onAddCustom: () -> Void
    @State private var query: String = ""
    @Environment(\.dismiss) private var dismiss

    private var filtered: [String] {
        let base = allItems.sorted()
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return base }
        return base.filter { $0.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        List {
            ForEach(filtered, id: \.self) { item in
                Button {
                    toggle(item)
                } label: {
                    HStack {
                        Text(item)
                        Spacer()
                        if selection.contains(item) {
                            Image(systemName: "checkmark").foregroundColor(BrandColors.primary)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search languages")
        .navigationTitle("Languages")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Add Other") { onAddCustom() } }
        }
    }

    private func toggle(_ item: String) {
        if selection.contains(item) { selection.remove(item) } else { selection.insert(item) }
    }
}

// MARK: - Validation
extension ProfileView {
    private func validateAge() -> Bool {
        ageError = nil
        let trimmed = vm.age.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return true }
        if let n = Int(trimmed), (16...99).contains(n) { return true }
        ageError = "Enter a valid age (16–99)"
        return false
    }
}
