import SwiftUI
import Combine

struct Destination: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let region: String
    let imageURL: URL?
}

final class SuggestionsViewModel: ObservableObject {
    @Published var destinations: [Destination] = []
    @Published var query: String = ""
    @Published var selectedRegion: String = "All"
    @Published var sort: Sort = .popular
    @AppStorage("suggestions.favorites") private var favoritesRaw: String = "" // comma-separated UUID strings

    enum Sort: String, CaseIterable, Identifiable { case popular = "Popular", name = "Name", region = "Region"; var id: String { rawValue } }

    var favoriteIDs: Set<UUID> {
        get { Set(favoritesRaw.split(separator: ",").compactMap { UUID(uuidString: String($0)) }) }
        set { favoritesRaw = newValue.map { $0.uuidString }.joined(separator: ",") }
    }

    var regions: [String] {
        ["All"] + Array(Set(destinations.map { $0.region })).sorted()
    }

    var filtered: [Destination] {
        var list = destinations
        if selectedRegion != "All" { list = list.filter { $0.region == selectedRegion } }
        if !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            list = list.filter { $0.name.localizedCaseInsensitiveContains(query) || $0.region.localizedCaseInsensitiveContains(query) }
        }
        switch sort {
        case .popular: // fake popularity: favorites first
            list.sort { (favoriteIDs.contains($0.id) ? 1 : 0) > (favoriteIDs.contains($1.id) ? 1 : 0) }
        case .name:
            list.sort { $0.name < $1.name }
        case .region:
            list.sort { $0.region < $1.region }
        }
        return list
    }

    func toggleFavorite(_ id: UUID) {
        var set = favoriteIDs
        if set.contains(id) { set.remove(id) } else { set.insert(id) }
        favoriteIDs = set
    }

    @MainActor
    func load() async {
        // Simulate fetch via LocalDestinationsAPI stub using hardcoded set for now
        await Task.sleep(200_000_000) // 0.2s
        destinations = [
            .init(name: "Sigiriya", region: "Central", imageURL: URL(string: "https://images.unsplash.com/photo-1627952960794-7bf279996843?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Galle Fort", region: "Southern", imageURL: URL(string: "https://images.unsplash.com/photo-1600500731216-c89d9b3da01f?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Ella", region: "Uva", imageURL: URL(string: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Anuradhapura", region: "North Central", imageURL: URL(string: "https://images.unsplash.com/photo-1548786811-dd434afc3a07?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Jaffna", region: "Northern", imageURL: URL(string: "https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Kandy", region: "Central", imageURL: URL(string: "https://images.unsplash.com/photo-1609249423527-1a5ee11ad1ed?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Colombo", region: "Western", imageURL: URL(string: "https://images.unsplash.com/photo-1616789914319-07e675985d8a?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Nuwara Eliya", region: "Central", imageURL: URL(string: "https://images.unsplash.com/photo-1573495618575-7d3f1908b2b5?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Mirissa", region: "Southern", imageURL: URL(string: "https://images.unsplash.com/photo-1526772662000-3f88f10405ff?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Trincomalee", region: "Eastern", imageURL: URL(string: "https://images.unsplash.com/photo-1579519315447-02a1a6c1891c?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Polonnaruwa", region: "North Central", imageURL: URL(string: "https://images.unsplash.com/photo-1613030885645-7c0b6de22db6?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Dambulla", region: "Central", imageURL: URL(string: "https://images.unsplash.com/photo-1584367369853-b7fcdba9dc3c?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Yala National Park", region: "Southern", imageURL: URL(string: "https://images.unsplash.com/photo-1543248939-ff40856b2a6c?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Arugam Bay", region: "Eastern", imageURL: URL(string: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Horton Plains", region: "Central", imageURL: URL(string: "https://images.unsplash.com/photo-1541936960-2f0a7d5a9d3f?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Adam's Peak", region: "Sabaragamuwa", imageURL: URL(string: "https://images.unsplash.com/photo-1584985593954-fb52d69f964b?q=80&w=900&auto=format&fit=crop")),
            .init(name: "Bentota", region: "Southern", imageURL: URL(string: "https://images.unsplash.com/photo-1500375592092-40eb2168fd21?q=80&w=900&auto=format&fit=crop"))
        ]
    }
}

struct SuggestionsView: View {
    @StateObject private var vm = SuggestionsViewModel()
    @State private var gridColumns = [GridItem(.flexible()), GridItem(.flexible())]
    @AppStorage("profile.name") private var profName: String = ""
    @AppStorage("profile.city") private var profCity: String = ""
    @AppStorage("profile.country") private var profCountry: String = ""
    @AppStorage("profile.languages") private var profLangs: String = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if !(profName.isEmpty && profCity.isEmpty && profLangs.isEmpty) {
                    SuggestionsProfileSummary(name: profName, location: composedLocation, languages: profLangs)
                        .padding(.horizontal)
                        .padding(.top, 6)
                }
                // Filters
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(vm.regions, id: \.self) { region in
                            Button(action: { vm.selectedRegion = region }) {
                                Text(region)
                                    .font(.caption)
                                    .padding(.horizontal, 10).padding(.vertical, 6)
                                    .background(vm.selectedRegion == region ? BrandColors.primary.opacity(0.15) : Color.gray.opacity(0.12))
                                    .foregroundColor(vm.selectedRegion == region ? BrandColors.primary : .primary)
                                    .clipShape(Capsule())
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                // Sort control
                Picker("Sort", selection: $vm.sort) {
                    ForEach(SuggestionsViewModel.Sort.allCases) { s in Text(s.rawValue).tag(s) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)

                LazyVGrid(columns: gridColumns, spacing: 12) {
                    ForEach(vm.filtered) { dest in
                        NavigationLink {
                            DestinationDetailView(destination: dest)
                        } label: {
                            DestinationCard(dest: dest, isFavorite: vm.favoriteIDs.contains(dest.id)) {
                                vm.toggleFavorite(dest.id)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
            }
        }
        .searchable(text: $vm.query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search destinations")
        .navigationTitle("Suggestions")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                NavigationLink("Plan Trip") { TripPlanView() }
            }
        }
        .task { await vm.load() }
        .refreshable { await vm.load() }
    }
}

private extension SuggestionsView {
    var composedLocation: String {
        let city = profCity.trimmingCharacters(in: .whitespaces)
        let country = profCountry.trimmingCharacters(in: .whitespaces)
        switch (city.isEmpty, country.isEmpty) {
        case (true, true): return ""
        case (false, true): return city
        case (true, false): return country
        default: return "\(city), \(country)"
        }
    }
}

struct SuggestionsProfileSummary: View {
    let name: String
    let location: String
    let languages: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: "person.crop.circle").foregroundColor(BrandColors.primary)
                Text(name.isEmpty ? "Profile" : name).font(.subheadline).bold()
                Spacer()
            }
            HStack(spacing: 12) {
                if !location.isEmpty {
                    Label(location, systemImage: "mappin.and.ellipse").font(.caption)
                }
                if !languages.isEmpty {
                    Label(languages, systemImage: "globe").font(.caption)
                }
            }
            .foregroundColor(.secondary)
        }
        .padding(10)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.06), radius: 4, x: 0, y: 2)
    }
}

struct DestinationCard: View {
    let dest: Destination
    var isFavorite: Bool
    var onToggleFavorite: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topTrailing) {
                AsyncImage(url: dest.imageURL) { phase in
                    switch phase {
                    case .empty:
                        ZStack { ProgressView() }
                            .frame(height: 120)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.2))
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 120)
                            .frame(maxWidth: .infinity)
                            .clipped()
                    case .failure:
                        ZStack {
                            Image(systemName: "photo")
                                .font(.title3)
                                .foregroundColor(.secondary)
                        }
                        .frame(height: 120)
                        .frame(maxWidth: .infinity)
                        .background(Color.gray.opacity(0.2))
                    @unknown default:
                        EmptyView()
                    }
                }
                Button(action: onToggleFavorite) {
                    Image(systemName: isFavorite ? "heart.fill" : "heart")
                        .foregroundColor(isFavorite ? .pink : .white)
                        .padding(8)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                        .padding(6)
                }
            }
            Text(dest.name)
                .font(.headline)
            Label(dest.region, systemImage: "mappin.and.ellipse")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.06), radius: 6, x: 0, y: 3)
    }
}

#Preview { NavigationStack { SuggestionsView() } }
