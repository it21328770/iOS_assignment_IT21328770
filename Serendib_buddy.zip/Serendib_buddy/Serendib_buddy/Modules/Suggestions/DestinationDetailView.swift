import SwiftUI

struct DestinationDetailView: View {
    let destination: Destination

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                AsyncImage(url: destination.imageURL) { phase in
                    switch phase {
                    case .empty:
                        ZStack { ProgressView() }
                            .frame(height: 220)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.2))
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 220)
                            .frame(maxWidth: .infinity)
                            .clipped()
                    case .failure:
                        ZStack {
                            Image(systemName: "photo")
                                .font(.title)
                                .foregroundColor(.secondary)
                        }
                        .frame(height: 220)
                        .frame(maxWidth: .infinity)
                        .background(Color.gray.opacity(0.2))
                    @unknown default:
                        EmptyView()
                    }
                }
                VStack(alignment: .leading, spacing: 8) {
                    Text(destination.name)
                        .font(.title2).bold()
                    Label(destination.region, systemImage: "mappin.and.ellipse")
                        .foregroundColor(.secondary)
                    Text("Description")
                        .font(.headline)
                        .padding(.top, 8)
                    Text("A beautiful place to explore in Sri Lanka. This is a placeholder description. You can replace it with real content fetched from your API.")
                        .foregroundColor(.secondary)
                }
                Button {
                    NotificationCenter.default.post(name: .addToTripPlan, object: nil, userInfo: [
                        "title": destination.name,
                        "location": destination.name
                    ])
                } label: {
                    Label("Add to Trip Plan", systemImage: "calendar.badge.plus")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .navigationTitle(destination.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview { NavigationStack { DestinationDetailView(destination: Destination(name: "Sigiriya", region: "Central", imageURL: nil)) } }
