import SwiftUI
import Combine
import MapKit
import CoreLocation
import UIKit

enum TravelMethod: String, CaseIterable, Identifiable, Equatable, Codable {
    case car = "Car"
    case train = "Train"
    case bus = "Bus"
    case tuk = "Tuk-tuk"
    case walk = "Walk"
    case bike = "Bike"
    var id: String { rawValue }
}

// MARK: - Directions ETA
extension TripPlanView {
    private func transportType(for method: TravelMethod) -> MKDirectionsTransportType {
        switch method {
        case .car, .tuk, .bus: return .automobile
        case .train: return .transit
        case .walk: return .walking
        case .bike: return .any
        }
    }

    private func fetchETA(for item: TripItem) async {
        guard let idx = vm.items.firstIndex(of: item), idx < vm.items.count - 1 else { return }
        let current = vm.items[idx]
        let next = vm.items[idx + 1]
        guard let lat1 = current.latitude, let lon1 = current.longitude, let lat2 = next.latitude, let lon2 = next.longitude else { return }
        let src = MKMapItem(placemark: .init(coordinate: .init(latitude: lat1, longitude: lon1)))
        let dst = MKMapItem(placemark: .init(coordinate: .init(latitude: lat2, longitude: lon2)))
        let req = MKDirections.Request()
        req.source = src; req.destination = dst; req.transportType = transportType(for: current.method)
        let dirs = MKDirections(request: req)
        do {
            let resp = try await dirs.calculate()
            if let route = resp.routes.first {
                let minutes = Int((route.expectedTravelTime / 60.0).rounded())
                await MainActor.run { etaCache[item.id] = minutes }
            }
        } catch {
            // Fallback to straight-line estimate if routing failed
            if let mins = estimatedTravelMinutes(toNextOf: item) {
                await MainActor.run { etaCache[item.id] = mins }
            }
        }
    }
}

// MARK: - Map Location Picker
struct LocationPickerView: View {
    @State private var region: MKCoordinateRegion
    @State private var address: String
    let onDone: (String, CLLocationCoordinate2D?) -> Void
    let onCancel: () -> Void

    init(initialAddress: String, initialCoordinate: CLLocationCoordinate2D?, onDone: @escaping (String, CLLocationCoordinate2D?) -> Void, onCancel: @escaping () -> Void) {
        self._address = State(initialValue: initialAddress)
        let coord = initialCoordinate ?? CLLocationCoordinate2D(latitude: 6.9271, longitude: 79.8612) // Colombo default
        self._region = State(initialValue: MKCoordinateRegion(center: coord, span: MKCoordinateSpan(latitudeDelta: 0.08, longitudeDelta: 0.08)))
        self.onDone = onDone
        self.onCancel = onCancel
    }

    var body: some View {
        VStack(spacing: 0) {
            Map(coordinateRegion: $region, interactionModes: [.all], showsUserLocation: false, userTrackingMode: .none)
                .overlay(alignment: .center) {
                    Image(systemName: "mappin.circle.fill").font(.title).foregroundColor(.red)
                        .shadow(radius: 4)
                }
                .frame(height: 320)
            Form {
                Section("Address") {
                    TextField("Address", text: $address)
                    Button("Use Dropped Pin") {
                        reverseGeocode(region.center) { addr in
                            address = addr ?? address
                        }
                    }
                }
            }
        }
        .navigationTitle("Pick Location")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Cancel", action: onCancel) }
            ToolbarItem(placement: .confirmationAction) { Button("Done") { onDone(address, region.center) } }
        }
    }

    private func reverseGeocode(_ coord: CLLocationCoordinate2D, completion: @escaping (String?) -> Void) {
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: coord.latitude, longitude: coord.longitude)) { placemarks, _ in
            if let p = placemarks?.first {
                let parts = [p.name, p.locality, p.country].compactMap { $0 }.joined(separator: ", ")
                completion(parts.isEmpty ? nil : parts)
            } else { completion(nil) }
        }
    }
}

extension TripPlanView {
    private func coordinateFromEdit() -> CLLocationCoordinate2D? {
        if let lat = editLatitude, let lon = editLongitude { return .init(latitude: lat, longitude: lon) }
        return nil
    }
}

// MARK: - Trip Row View
struct TripRowView: View {
    let item: TripItem
    let routeCoords: [CLLocationCoordinate2D]?
    let etaMinutes: Int?
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onDuplicate: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(item.title)
                Spacer()
                Button(action: onEdit) {
                    Image(systemName: "pencil")
                        .foregroundColor(.primary)
                        .accessibilityLabel("Edit \(item.title)")
                }
            }
            if let lat = item.latitude, let lon = item.longitude {
                Map {
                    MapCircle(center: .init(latitude: lat, longitude: lon), radius: 50)
                        .stroke(.blue.opacity(0.6))
                    if let coords = routeCoords, !coords.isEmpty {
                        let poly = MKPolyline(coordinates: coords, count: coords.count)
                        MapPolyline(poly)
                            .stroke(.blue, lineWidth: 3)
                    }
                }
                .frame(height: 140)
                .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            HStack(spacing: 12) {
                Label(item.location.isEmpty ? "Add location" : item.location, systemImage: "mappin.and.line")
                    .font(.caption)
                    .foregroundColor(item.location.isEmpty ? .secondary : .primary)
                Divider()
                Label(item.method.rawValue, systemImage: iconName(for: item.method))
                    .font(.caption)
                Divider()
                if let t = item.time {
                    Label(t.formatted(date: .omitted, time: .shortened), systemImage: "clock")
                        .font(.caption)
                } else {
                    Label("Set time", systemImage: "clock")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                if let mins = etaMinutes {
                    Divider()
                    Label("~\(mins) min", systemImage: "figure.walk.motion")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            if !item.notes.isEmpty {
                Text(item.notes)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
            Button(role: .destructive, action: onDelete) { Label("Delete", systemImage: "trash") }
        }
        .swipeActions(edge: .leading) {
            Button(action: onDuplicate) { Label("Duplicate", systemImage: "plus.square.on.square") }
                .tint(.blue)
        }
    }
}
private func haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
    let R = 6371.0
    let dLat = (lat2 - lat1) * .pi / 180
    let dLon = (lon2 - lon1) * .pi / 180
    let a = sin(dLat/2)*sin(dLat/2) + cos(lat1 * .pi/180) * cos(lat2 * .pi/180) * sin(dLon/2)*sin(dLon/2)
    let c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R * c
}

private func speedKmh(for method: TravelMethod) -> Double {
    switch method {
    case .car: return 45
    case .train: return 60
    case .bus: return 35
    case .tuk: return 25
    case .walk: return 5
    case .bike: return 15
    }
}
private enum GeocodingHelper {
    static func geocode(address: String, completion: @escaping (CLLocationCoordinate2D?) -> Void) {
        guard !address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { completion(nil); return }
        CLGeocoder().geocodeAddressString(address) { placemarks, _ in
            if let loc = placemarks?.first?.location?.coordinate { completion(loc) } else { completion(nil) }
        }
    }
}

final class LocationSearchViewModel: ObservableObject {
    @Published var query: String = "" { didSet { update() } }
    @Published var suggestions: [String] = []
    private let completer = MKLocalSearchCompleter()
    init() { completer.resultTypes = .address; completer.region = MKCoordinateRegion(.world); }
    private func update() {
        guard query.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 else { suggestions = []; return }
        completer.queryFragment = query
        completer.resultTypes = [.address, .pointOfInterest]
        completer.region = MKCoordinateRegion(.world)
        completerCompletion()
    }
    private func completerCompletion() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            self.suggestions = self.completer.results.prefix(6).map { $0.title + ( $0.subtitle.isEmpty ? "" : ", \($0.subtitle)" ) }
        }
    }
}

struct TripItem: Identifiable, Equatable, Codable { let id: UUID; var title: String; var time: Date?; var location: String; var method: TravelMethod; var notes: String; var latitude: Double?; var longitude: Double? 
    init(id: UUID = UUID(), title: String, time: Date?, location: String, method: TravelMethod, notes: String, latitude: Double? = nil, longitude: Double? = nil) {
        self.id = id; self.title = title; self.time = time; self.location = location; self.method = method; self.notes = notes; self.latitude = latitude; self.longitude = longitude
    }
}

private enum TripStorage {
    static var url: URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return dir.appendingPathComponent("trip_plan.json")
    }
    static func load() -> [TripItem] {
        guard let data = try? Data(contentsOf: url) else { return [] }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return (try? decoder.decode([TripItem].self, from: data)) ?? []
    }
    static func save(_ items: [TripItem]) {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted]; encoder.dateEncodingStrategy = .iso8601
        if let data = try? encoder.encode(items) { try? data.write(to: url, options: .atomic) }
    }
}

final class TripPlanViewModel: ObservableObject {
    @Published var items: [TripItem] = [
        TripItem(title: "Day 1: Colombo", time: Date(), location: "Colombo", method: .car, notes: "City highlights"),
        TripItem(title: "Day 2: Kandy", time: Calendar.current.date(byAdding: .day, value: 1, to: Date()), location: "Kandy", method: .train, notes: "Temple of the Tooth")
    ]
    func add() { items.append(TripItem(title: "New Day", time: nil, location: "", method: .car, notes: "")) }
    func delete(at offsets: IndexSet) { items.remove(atOffsets: offsets) }
    func move(from source: IndexSet, to destination: Int) { items.move(fromOffsets: source, toOffset: destination) }
    func update(id: UUID, title: String, time: Date?, location: String, method: TravelMethod, notes: String, latitude: Double?, longitude: Double?) {
        if let idx = items.firstIndex(where: { $0.id == id }) {
            items[idx].title = title
            items[idx].time = time
            items[idx].location = location
            items[idx].method = method
            items[idx].notes = notes
            items[idx].latitude = latitude
            items[idx].longitude = longitude
        }
    }
    func duplicate(id: UUID) {
        guard let item = items.first(where: { $0.id == id }) else { return }
        let copy = TripItem(title: item.title + " (Copy)", time: item.time, location: item.location, method: item.method, notes: item.notes)
        items.append(copy)
    }
    enum Template: String, CaseIterable, Identifiable { case beachDay = "Beach Day", cultureTour = "Culture Tour", wildlife = "Wildlife"; var id: String { rawValue } }
    func addTemplate(_ template: Template) {
        switch template {
        case .beachDay:
            items.append(contentsOf: [
                TripItem(title: "Morning: Beach", time: nil, location: "Unawatuna", method: .tuk, notes: "Swim & relax"),
                TripItem(title: "Afternoon: Cafe", time: nil, location: "Galle", method: .car, notes: "Seafood lunch"),
                TripItem(title: "Sunset: Fort Walls", time: nil, location: "Galle Fort", method: .walk, notes: "Photos")
            ])
        case .cultureTour:
            items.append(contentsOf: [
                TripItem(title: "Sigiriya Rock", time: nil, location: "Sigiriya", method: .car, notes: "Early start"),
                TripItem(title: "Dambulla Cave Temple", time: nil, location: "Dambulla", method: .car, notes: "Caves"),
                TripItem(title: "Village Tour", time: nil, location: "Hiriwadunna", method: .tuk, notes: "Local life")
            ])
        case .wildlife:
            items.append(contentsOf: [
                TripItem(title: "Safari", time: nil, location: "Yala", method: .car, notes: "Leopard chance"),
                TripItem(title: "Birdwatching", time: nil, location: "Bundala", method: .car, notes: "Binoculars"),
                TripItem(title: "Camping", time: nil, location: "Yala", method: .car, notes: "Overnight")
            ])
        }
    }
}

struct TripPlanView: View {
    @StateObject private var vm = TripPlanViewModel()
    @State private var editingItem: TripItem? = nil
    @State private var editTitle: String = ""
    @State private var editTime: Date = Date()
    @State private var editHasTime: Bool = false
    @State private var editLocation: String = ""
    @State private var editMethod: TravelMethod = .car
    @State private var editNotes: String = ""
    @StateObject private var searchVM = LocationSearchViewModel()
    @State private var shareText: String = ""
    @State private var editLatitude: Double? = nil
    @State private var editLongitude: Double? = nil
    @State private var showLocationPicker: Bool = false
    @State private var etaCache: [UUID: Int] = [:]

    var body: some View {
        VStack {
            List {
                ForEach(vm.items) { item in
                    TripRowView(
                        item: item,
                        routeCoords: routePolyline(for: item),
                        etaMinutes: etaCache[item.id],
                        onEdit: {
                            editingItem = item
                            editTitle = item.title
                            editTime = item.time ?? Date()
                            editHasTime = item.time != nil
                            editLocation = item.location
                            editMethod = item.method
                            editNotes = item.notes
                            searchVM.query = ""
                        },
                        onDelete: {
                            if let idx = vm.items.firstIndex(of: item) { vm.items.remove(at: idx) }
                        },
                        onDuplicate: { vm.duplicate(id: item.id) }
                    )
                    .task {
                        if etaCache[item.id] == nil, routePolyline(for: item) != nil {
                            await fetchETA(for: item)
                        }
                    }
                }
                .onDelete(perform: vm.delete)
                .onMove(perform: vm.move)
            }
            Button("Add Day") { vm.add() }
                .buttonStyle(.borderedProminent)
                .padding()
        }
        .navigationTitle("Trip Plan")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                EditButton()
            }
            ToolbarItem(placement: .navigationBarLeading) {
                Menu {
                    ShareLink(item: shareContent()) { Label("Share Text", systemImage: "doc.text") }
                    Button { if let url = exportItineraryPDF() { presentSharePDF(url: url) } } label: { Label("Share PDF", systemImage: "doc.richtext") }
                } label: {
                    Label("Share", systemImage: "square.and.arrow.up")
                }
            }
        }
        .sheet(item: $editingItem) { item in
            NavigationStack {
                Form {
                    Section("Title") {
                        TextField("Title", text: $editTitle)
                    }
                    Section("Time") {
                        Toggle("Set a time", isOn: $editHasTime)
                        if editHasTime {
                            DatePicker("Time", selection: $editTime, displayedComponents: .hourAndMinute)
                        }
                    }
                    Section("Location") {
                        TextField("Location", text: $editLocation)
                            .onChange(of: editLocation) { _ in
                                // user typed manually; clear coordinates to re-geocode on save
                                editLatitude = nil; editLongitude = nil
                            }
                        if !searchVM.suggestions.isEmpty {
                            List(searchVM.suggestions, id: \.self) { suggestion in
                                Button {
                                    editLocation = suggestion
                                    editLatitude = nil; editLongitude = nil
                                    searchVM.query = ""
                                } label: {
                                    Label(suggestion, systemImage: "mappin")
                                }
                            }
                            .frame(maxHeight: 160)
                        }
                        Button {
                            showLocationPicker = true
                        } label: {
                            Label("Pick on Map", systemImage: "map")
                        }
                    }
                    Section("Travel Method") {
                        Picker("Method", selection: $editMethod) {
                            ForEach(TravelMethod.allCases) { method in
                                Label(method.rawValue, systemImage: iconName(for: method))
                                    .tag(method)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                    Section("Notes") {
                        TextEditor(text: $editNotes)
                            .frame(minHeight: 100)
                    }
                }
                .navigationTitle("Edit Day")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { editingItem = nil }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save") {
                            if let lat = editLatitude, let lon = editLongitude {
                                vm.update(id: item.id, title: editTitle, time: editHasTime ? editTime : nil, location: editLocation, method: editMethod, notes: editNotes, latitude: lat, longitude: lon)
                                editingItem = nil
                            } else {
                                GeocodingHelper.geocode(address: editLocation) { coord in
                                    vm.update(id: item.id, title: editTitle, time: editHasTime ? editTime : nil, location: editLocation, method: editMethod, notes: editNotes, latitude: coord?.latitude, longitude: coord?.longitude)
                                    editingItem = nil
                                }
                            }
                        }
                    }
                }
            }
            .presentationDetents([.medium, .large])
        }
        .onChange(of: editLocation) { newValue in
            searchVM.query = newValue
        }
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Menu {
                    ForEach(TripPlanViewModel.Template.allCases) { t in
                        Button(t.rawValue) { vm.addTemplate(t) }
                    }
                } label: {
                    Label("Add from Template", systemImage: "list.bullet.rectangle.portrait")
                }
            }
        }
        .onAppear { loadOrPersistInitial() }
        .onChange(of: vm.items) { items in TripStorage.save(items) }
        .sheet(isPresented: $showLocationPicker) {
            NavigationStack {
                LocationPickerView(initialAddress: editLocation, initialCoordinate: coordinateFromEdit(), onDone: { addr, coord in
                    editLocation = addr
                    editLatitude = coord?.latitude
                    editLongitude = coord?.longitude
                    showLocationPicker = false
                }, onCancel: {
                    showLocationPicker = false
                })
            }
        }
    }

    // MARK: - Helpers that access vm
    private func shareContent() -> String {
        var lines: [String] = ["Trip Plan"]
        for item in vm.items {
            var line = "• \(item.title)"
            if let t = item.time { line += " at \(t.formatted(date: .omitted, time: .shortened))" }
            if !item.location.isEmpty { line += " — \(item.location)" }
            line += " [\(item.method.rawValue)]"
            if !item.notes.isEmpty { line += " — \(item.notes)" }
            lines.append(line)
        }
        return lines.joined(separator: "\n")
    }

    private func estimatedTravelMinutes(toNextOf item: TripItem) -> Int? {
        guard let idx = vm.items.firstIndex(of: item), idx < vm.items.count - 1 else { return nil }
        let current = vm.items[idx]
        let next = vm.items[idx + 1]
        guard let lat1 = current.latitude, let lon1 = current.longitude, let lat2 = next.latitude, let lon2 = next.longitude else { return nil }
        let distanceKm = haversineKm(lat1: lat1, lon1: lon1, lat2: lat2, lon2: lon2)
        let speed = speedKmh(for: current.method)
        let hours = distanceKm / speed
        let minutes = Int((hours * 60).rounded())
        return minutes
    }

    private func loadOrPersistInitial() {
        let loaded = TripStorage.load()
        if !loaded.isEmpty { vm.items = loaded }
        else { TripStorage.save(vm.items) }
    }

    private func routePolyline(for item: TripItem) -> [CLLocationCoordinate2D]? {
        guard let idx = vm.items.firstIndex(of: item), idx < vm.items.count - 1 else { return nil }
        let current = vm.items[idx]
        let next = vm.items[idx + 1]
        guard let lat1 = current.latitude, let lon1 = current.longitude, let lat2 = next.latitude, let lon2 = next.longitude else { return nil }
        return [CLLocationCoordinate2D(latitude: lat1, longitude: lon1), CLLocationCoordinate2D(latitude: lat2, longitude: lon2)]
    }

    private func exportItineraryPDF() -> URL? {
        let fmtText = shareContent()
        let pageRect = CGRect(x: 0, y: 0, width: 612, height: 792) // US Letter
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let data = renderer.pdfData { ctx in
            ctx.beginPage()
            // Brand header
            let headerRect = CGRect(x: 0, y: 0, width: pageRect.width, height: 80)
            let start = UIColor(red: 6/255, green: 82/255, blue: 67/255, alpha: 1)
            let end = UIColor(red: 14/255, green: 124/255, blue: 102/255, alpha: 1)
            let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [start.cgColor, end.cgColor] as CFArray, locations: [0,1])!
            let ctxRef = UIGraphicsGetCurrentContext()!
            ctxRef.saveGState()
            ctxRef.addRect(headerRect)
            ctxRef.clip()
            ctxRef.drawLinearGradient(gradient, start: CGPoint(x: 0, y: 0), end: CGPoint(x: pageRect.width, y: 80), options: [])
            ctxRef.restoreGState()
            // Title over header
            let titleAttrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: 20),
                .foregroundColor: UIColor.white
            ]
            ("Travel Buddy Matcher — Trip Plan" as NSString).draw(at: CGPoint(x: 24, y: 28), withAttributes: titleAttrs)
            let bodyAttrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 12)
            ]
            let bodyRect = CGRect(x: 36, y: 100, width: pageRect.width - 72, height: pageRect.height - 130)
            (fmtText as NSString).draw(in: bodyRect, withAttributes: bodyAttrs)
        }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("Itinerary.pdf")
        do { try data.write(to: url); return url } catch { return nil }
    }

    private func presentSharePDF(url: URL) {
        // No-op placeholder for programmatic share; we rely on ShareLink menu above
        _ = url
    }
}

private func iconName(for method: TravelMethod) -> String {
    switch method {
    case .car: return "car.fill"
    case .train: return "train.side.front.car"
    case .bus: return "bus.fill"
    case .tuk: return "scooter"
    case .walk: return "figure.walk"
    case .bike: return "bicycle"
    }
}

#Preview {
    NavigationStack { TripPlanView() }
}
