import Foundation

extension Notification.Name {
    static let addToTripPlan = Notification.Name("addToTripPlan")
}
