import SwiftUI

struct SwipeCardView<Content: View>: View {
    let content: () -> Content
    var onSwipeLeft: () -> Void
    var onSwipeRight: () -> Void
    @Binding var trigger: SwipeDirection?

    @State private var offset: CGSize = .zero
    @GestureState private var isDragging: Bool = false

    var body: some View {
        content()
            .offset(offset)
            .rotationEffect(.degrees(Double(offset.width / 20)))
            .shadow(radius: 8)
            .gesture(
                DragGesture()
                    .updating($isDragging) { _, state, _ in state = true }
                    .onChanged { value in
                        offset = value.translation
                    }
                    .onEnded { value in
                        if value.translation.width > 120 { onSwipeRight(); reset() }
                        else if value.translation.width < -120 { onSwipeLeft(); reset() }
                        else { withAnimation(.spring()) { offset = .zero } }
                    }
            )
            .onChange(of: trigger) { dir in
                guard let dir = dir else { return }
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    switch dir {
                    case .left: offset = CGSize(width: -500, height: 0)
                    case .right: offset = CGSize(width: 500, height: 0)
                    }
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    if dir == .left { onSwipeLeft() } else { onSwipeRight() }
                    reset()
                    trigger = nil
                }
            }
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: offset)
    }

    private func reset() {
        withAnimation(.spring()) { offset = .zero }
    }
}

enum SwipeDirection { case left, right }
