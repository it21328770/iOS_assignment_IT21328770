import SwiftUI

struct AppLogoView: View {
    var body: some View {
        ZStack {
            // Gradient background (Option B)
            LinearGradient(
                colors: [BrandColors.gradientStart, BrandColors.gradientEnd],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            // Emblem: simple stupa + wave (minimal geometry)
            GeometryReader { geo in
                let w = geo.size.width
                let h = geo.size.height
                let centerX = w / 2
                let baseY = h * 0.65

                // Wave
                Path { p in
                    p.move(to: CGPoint(x: 0, y: baseY))
                    p.addCurve(
                        to: CGPoint(x: w, y: baseY - h*0.06),
                        control1: CGPoint(x: w*0.33, y: baseY - h*0.12),
                        control2: CGPoint(x: w*0.66, y: baseY + h*0.02)
                    )
                    p.addLine(to: CGPoint(x: w, y: h))
                    p.addLine(to: CGPoint(x: 0, y: h))
                    p.closeSubpath()
                }
                .fill(BrandColors.accent.opacity(0.25))

                // Stupa base
                RoundedRectangle(cornerRadius: 6)
                    .fill(Color.white.opacity(0.92))
                    .frame(width: w*0.46, height: h*0.08)
                    .position(x: centerX, y: baseY - h*0.02)

                // Stupa dome
                Circle()
                    .fill(Color.white)
                    .frame(width: w*0.30, height: w*0.30)
                    .position(x: centerX, y: baseY - h*0.16)

                // Pinnacle
                Capsule()
                    .fill(Color.white)
                    .frame(width: w*0.04, height: h*0.16)
                    .position(x: centerX, y: baseY - h*0.35)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(Color.white.opacity(0.08), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 8)
        .accessibilityLabel("App logo: stupa and wave over emerald gradient")
    }
}

#Preview {
    AppLogoView()
        .frame(width: 160, height: 160)
        .padding()
}
