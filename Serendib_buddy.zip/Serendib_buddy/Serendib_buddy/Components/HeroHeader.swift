import SwiftUI

struct HeroHeader: View {
    let title: String
    let subtitle: String
    let imageURL: URL

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            AsyncImage(url: imageURL) { phase in
                switch phase {
                case .empty:
                    ZStack { ProgressView() }
                        .frame(maxWidth: .infinity, maxHeight: 240)
                        .background(Color.gray.opacity(0.2))
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity, maxHeight: 240)
                        .clipped()
                case .failure:
                    ZStack {
                        Image(systemName: "photo")
                            .font(.largeTitle)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: 240)
                    .background(Color.gray.opacity(0.2))
                @unknown default:
                    EmptyView()
                }
            }
            LinearGradient(colors: [.clear, .black.opacity(0.6)], startPoint: .center, endPoint: .bottom)
                .frame(height: 120)
                .frame(maxWidth: .infinity, alignment: .bottom)
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.title).bold().foregroundColor(.white)
                Text(subtitle).font(.subheadline).foregroundColor(.white.opacity(0.9))
            }
            .padding()
        }
        .frame(height: 240)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(radius: 6)
    }
}

#Preview {
    HeroHeader(
        title: "Discover Sri Lanka",
        subtitle: "Beaches, Culture, Wildlife",
        imageURL: URL(string: "https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1200&auto=format&fit=crop")!
    ).padding()
}
